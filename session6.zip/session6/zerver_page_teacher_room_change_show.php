<?php

session_start();

error_reporting(0);

echo $_SESSION["teacher_curr_room"];

?>